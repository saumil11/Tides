/* Helpful Notes:
SoundManager functions: 
playFile(String filename);    -> plays the file that is located in the res folder
waitQuareter();				-> plays no sound for 250 milliseconds
waitHalf();				-> plays no sound for 500 milliseconds
waitSecond();				-> plays no sound for 1000 milliseconds (1 second)*/

public class Main {

	SoundManager studio = new SoundManager();    // Creates an instance of the SoundManager class called studio 
    UIManager UI = new UIManager(this);			// Creates an instance of the UIManager
           
	public static void main(String[] args) {   
		Main m = new Main();              // Creates an instance of Main
	}
	
	public void myBeatClicked() throws Exception{  			 // Function Called when the MyBeat Button is clicked
		String beat1 = "beat1.wav";			// assign file names to strings
		String beat2 = "beat2.wav";
		String beat3 = "beat3.wav";
		String beat4 = "beat4.wav";
		String beat5 = "beat5.wav";
		String beat6 = "beat6.wav";
		String beat7 = "beat7.wav";
		String background1 = "background1.wav";
		String background2 = "background2.wav";
		String background3 = "background3.wav";
		String background4 = "background4.wav";
		String background5 = "background5.wav";
		String background6 = "background6.wav";
		String background7 = "background7.wav";

		//Write your solution here
	}
}
