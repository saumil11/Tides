//playPianoNote(int note); plays specified note. Range must be between 1-8
//wait(int milliseconds); waits for a specified time in milliseconds.

public class Main {
	public static void main(String[] args) {
		SoundManager studio = new SoundManager();
		
	}
}
