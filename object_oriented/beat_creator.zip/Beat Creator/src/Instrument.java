public class Instrument extends SoundManager {
	
}
