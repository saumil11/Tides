public class Main {

	boolean[][] cb;   // used to store the two dimensional array of check boxes
	String[] t = {"instrument1","instrument2","instrument3"};   // used for the labels next to the check boxes
	UIManager um;
	
	private Main() {
		um = new UIManager(this,3,8);    // Creates a UI with 3 instruments and 8 columns of checkboxes you may change the dimenstions as you wish
		cb = um.getArrayofCheckBoxes();
		um.setLabels(t);
	}	

	public static void main(String[] args) {
		new Main();
		
	}
	
	void PlayButtonClicked(){            //Function called when the play button is clicked
		
		// Add your code here
		
	}
}
