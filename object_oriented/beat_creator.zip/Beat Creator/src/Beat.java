public class Beat extends SoundManager{

}


