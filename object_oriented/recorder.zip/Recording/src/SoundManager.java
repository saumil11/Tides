/**			SoundManager Class
 * This class allows beginner programmers to easily play sound in their java programs.
 * Author: Dani Odicho
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.LinkedList;
import java.net.URL; // added

import sun.audio.AudioData; //added
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class SoundManager 
{
	AudioStream audioStream = null;
	LinkedList<AudioStream> audioStreams = new LinkedList<AudioStream>();
	LinkedList<String> filenames = new LinkedList<String>();
	

	/** Stops all the currently playing files. */
	public void stopAllFiles() 
	{
		while (!audioStreams.isEmpty()) 
		{
			stopFile();
		}
	}

	/**
	 * <pre>
	 * Stops the playing of the first file that was being played
	 * for example: if user played file1 then file2 then file3.
	 * If the user calls this method, file1 will be stopped.
	 * If the user calls the method again, then file2 will be stopped.
	 * If the user calls the method a third time, then file3 will be stopped.
	 * </pre>
	 */
	public void stopFile() 
	{
		AudioPlayer.player.stop(audioStreams.pollFirst());
		filenames.pollFirst();
	}

	/**
	 * Stops the playing of a specific file.
	 * 
	 * @param filename
	 *            The name of the file to be stopped.
	 */
	public void stopFile(String filename) 
	{
		try 
		{
			int index = filenames.indexOf(filename);
			AudioPlayer.player.stop(audioStreams.get(index));
			audioStreams.remove(index);
			filenames.remove(index);
		} catch (IndexOutOfBoundsException ie) 
		{
			System.out.println("Error! The file " + filename
					+ " is not being played at this instance.\n");
		}
	}

	/**
	 * Plays a a sound file located in the resource folder.
	 * 
	 * @param filename
	 *            The full name of a sound file located in the resource folder
	 *            of the project.
	 */
	public void playFile(String filename)
	{
	    InputStream in = null;
		try 
		{
			in = new FileInputStream("res/" + filename);
		} catch (FileNotFoundException e) 
		{
			System.out.println("Couldn't find the file. Make sure the file is in the \"res\" folder");
		}
		audioStream = null;
		try 
		{
			audioStream = new AudioStream(in);
			audioStreams.add(audioStream);
			filenames.add(filename);
	
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    AudioPlayer.player.start(audioStream);
	}
	/*
	public float [] getSamples(String filename)
	{
		
		float [] samples;
		InputStream in = null;
		try 
		{
			in = new FileInputStream("res/" + filename);
		} catch (FileNotFoundException e) 
		{
			System.out.println("Couldn't find the file. Make sure the file is in the \"res\" folder");
		}
		audioStream = null;
		try 
		{
			audioStream = new AudioStream(in);
		
			byte [] byteAry = new byte[audioStream.getLength()];
			audioStream.read(byteAry);
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return samples;
	}
	*/
	/*
	 * public void playFile(final String filename) { Thread t = new Thread(new
	 * Runnable() { public void run() {/ try { File file = new File(filename);
	 * AudioInputStream kickAudioStream =
	 * AudioSystem.getAudioInputStream(getClass().getResource(filename));
	 * 
	 * Clip soundClip = AudioSystem.getClip(); soundClip.open(kickAudioStream);
	 * soundClip.start();
	 * 
	 * /*The following loop keeps the thread running until the clips is finished
	 * plying the sound file.Without this while loop, the user can not play a
	 * sound file at the end of the program,because when main reaches the end
	 * the thread stops even if the sound file is still being played.
	 * 
	 * while (soundClip.getMicrosecondLength() !=
	 * soundClip.getMicrosecondPosition()) {}
	 * 
	 * /*The following two lines of code prevent the program from crashing when
	 * the soundClips is overloaded with many sound files to play.
	 * 
	 * soundClip.flush(); kickAudioStream.close(); //soundClip.flush();
	 * 
	 * } catch (UnsupportedAudioFileException e) { e.printStackTrace(); } catch
	 * (IOException e) { e.printStackTrace(); } catch (LineUnavailableException
	 * e) { e.printStackTrace(); } } }); t.start(); }
	 */

	/** Plays a snare drum sound once. */
	/**
	 * Requires the existence of a file named "snare.wav" in the project
	 * resource folder.
	 */
	public void playSnare() 
	{
		playFile("snare.wav");
	}

	/**
	 * Plays a bass drum sound once. Requires the existence of a file named
	 * "bass.wav" in the project resource folder.
	 */
	public void playBass() 
	{
		playFile("bass.wav");
	}

	/**
	 * <pre>
	 * Generates a random piano note of seven possibilities 
	 * (C,D,E,F,G,A,B) and returns a corresponding integer.
	 * @return int 1 if generated note is C
	 * int 2 if generated note is D
	 * int 3 if generated note is E
	 * int 4 if generated note is F
	 * int 5 if generated note is G
	 * int 6 if generated note is A
	 * int 7 if generated note is B
	 * Requires the existence of sound files ("C.wav", "D.wav", "E.wav", "F.wav", "G.wav", "A.wav", "B.wav") located in the project resource folder.
	 * </pre>
	 */
	public int generateNote() 
	{
		int index = (int) (Math.random() * 7.0D);
		String[] Notes = { "C.wav", "D.wav", "E.wav", "F.wav", "G.wav",
				"A.wav", "B.wav" };
		playFile(Notes[index]);
		waitSecond();
		return index + 1;
	}

	/** (r) Used to add a time gap of 1 second after playing a sound. */
	public void waitSecond() 
	{
		try 
		{
			Thread.sleep(1000L);
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}

	/** (r) Used to add a time gap of half a second after playing a sound. */
	public void waitHalf()
	{
		try 
		{
			Thread.sleep(500L);
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * (r) Used to add a time gap of a quarter of a second after playing a
	 * sound.
	 */
	public void waitQuarter() 
	{
		try 
		{
			Thread.sleep(250L);
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * (r) Used to add a time gap of an eighth of a second after playing a
	 * sound.
	 */
	public void waitEighth() 
	{
		try 
		{
			Thread.sleep(125L);
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}

	public void wait(int milliseconds) 
	{
		try 
		{
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * <pre>
	 * Used to play a piano note.
	 * 	  @param index note value between 1 and 7. 
	 * 	  plays a C note if index = 1.
	 * 	  plays a D note if index = 2.
	 * 	  plays a E note if index = 3.
	 * 	  plays a F note if index = 4.
	 * 	  plays a G note if index = 5.
	 * 	  plays a A note if index = 6.
	 * 	  plays a B note if index = 7.
	 * </pre>
	 */
	public void playPianoNote(int index) 
	{
		switch (index) 
		{
			case 1:
				playFile("C.wav");
				break;
			case 2:
				playFile("D.wav");
				break;
			case 3:
				playFile("E.wav");
				break;
			case 4:
				playFile("F.wav");
				break;
			case 5:
				playFile("G.wav");
				break;
			case 6:
				playFile("A.wav");
				break;
			case 7:
				playFile("B.wav");
				break;
			default:
				System.out
					.println("Couldn't generate note. Make sure the parameter is between 1 and 7.");
		}
	}
}