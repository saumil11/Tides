import java.util.Scanner;

public class Main
{	
	public static void main(String[] args) 
	{
		Microphone mic = new Microphone();
		AudioClip audio = new AudioClip();
		Scanner in = new Scanner(System.in);
		int selection = -1;
		int loopNTimes = 0;
		while(selection != 0)
		{
			System.out.println("1) Play Audio\n"
							 + "2) Stop Audio\n"
							 + "3) Start Recording\n"
							 + "4) Stop Recording\n"
							 + "5) Loop Clip n times\n"
							 + "0) Quit");
		    selection = in.nextInt();
		   if(selection == 1)
		   {
			   
		   }
		   else if(selection == 2)
		   {
			  
		   }
		   else if(selection == 3)
		   {
			  
		   }
		   else if(selection == 4)
		   {
			  
		   }
			else if(selection == 5)
		   {
			   System.out.println("Enter the int number of times the clip will be looped or -1 for loop forever.\n");
			   loopNTimes = in.nextInt();
			  
		   }
		   else if(selection == 0)
		   {
			  
		   }
		}
		in.close();
	}
}
