/*
Nick Schaafsma
Modified some code from this source:
http://www.java-tips.org/java-se-tips/javax.sound/capturing-audio-with-java-sound-api.html
*/

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.sound.sampled.*;
import javax.swing.*;

public class Microphone extends JFrame
{
	Clip audioClip;
	AudioInputStream audioIn;
	String audioClipName;
	JPanel panel;
	ByteArrayOutputStream out;
	boolean isRecording;
	byte buffer[];
	AudioFormat format;
	float sampleRate;
	TargetDataLine line ;
	
	/*
	 * Constructs an empty Microphone object. (note: Microphone extends JFrame)
	 */
	public Microphone()
	{
		panel = new JPanel();
		this.add(panel);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setSize(300, 200);
	    this.setVisible(true);
	}
	
	/**
	 * Starts recording with the microphone.
	 * 
	 * @param channelSampleRateInHz is a specification for how many samples will be captured on each channel per second.
	 * @param numOfChannels is the number of channels that the recording should be played back on. (e.g. mono == 1, stereo == 2, ...)
	 * @param sizeOfOneSampleInBits is the formatted size of one sample specified in bits. (e.g. 8 bit, 16 bit, ...)
	 * @see stopRecording(), isRecording()
	 */
	public void startRecording(final int channelSampleRateInHz,final int numOfChannels, final int sizeOfOneSampleInBits)
	{
		try {
	         audioClip = AudioSystem.getClip();
	      } catch (LineUnavailableException e) {
	         e.printStackTrace();
	      }
		Runnable recordRunner = new Runnable() {
			public void run()
			{
				sampleRate = channelSampleRateInHz*numOfChannels;
				format = new AudioFormat( sampleRate,  sizeOfOneSampleInBits, 
						numOfChannels,  true,  true) ;
				DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
				try {
					line = (TargetDataLine) AudioSystem.getLine(info);
					line.open();
					line.start();
			
				        int bufferSize = (int)format.getSampleRate()  * format.getFrameSize();
				        buffer  = new byte[bufferSize];
				 
		
				          out = new ByteArrayOutputStream();
				          isRecording = true;
				          try {
				            while (isRecording) {
				              int count = 
				                line.read(buffer, 0, buffer.length);
				              if (count > 0) {
				                out.write(buffer, 0, count);
				              }
				            }
				            out.close();
				          } catch (IOException e) {
				            System.err.println("I/O problems: " + e);
				            System.exit(-1);
				          }
					    } catch (LineUnavailableException e) {
					      System.err.println("Line unavailable: " + e);
					      System.exit(-2);
					    }
				//System.out.println("Recording Complete");	
			}
		};
		Thread recordThread = new Thread(recordRunner);
		recordThread.start();
	}
	/**
	 * Starts recording with the microphone with a default of 16 bits per sample.
	 * 
	 * @param channelSampleRateInHz is a specification for how many samples will be captured on each channel per second.
	 * @param numOfChannels is the number of channels that the recording should be played back on. (e.g. mono == 1, stereo == 2, ...)
	 * @see stopRecording(), isRecording()
	 */
	public void startRecording(int channelSampleRateInHz, int numOfChannels)
	{
		startRecording(channelSampleRateInHz, numOfChannels, 16);
	}
	
	/**
	 * Starts recording with a default of 16 bits per sample, 
	 * a default channel sample rate of 22050 hz, and a default of 2 channels (stereo) for playing back the sound. 
	 *
	 * @see stopRecording(), isRecording()
	 */
	public void startRecording()
	{
		startRecording(22050, 2, 16); //default
	}
	
	/**
	 * Stops recording and returns a Clip. This also sets all the public attributes of the Microphone class 
	 * which can be accessed through the get methods.
	 * 
	 *@return Clip is from javax.sound.sampled
	 * @see Clip, startRecording(), getAudioInputStream(), getAudioFormat(), getData()
	 */
	public Clip stopRecording()
	{
		isRecording = false;
		byte audio[] = out.toByteArray();
		  InputStream input = 
		    new ByteArrayInputStream(audio);
		  
		  audioIn = 
		    new AudioInputStream(input, format, 
		    audio.length / format.getFrameSize()); 
		  line.close();
		return audioClip;
	}
	
	/**
	 * Returns an AudioFormat specified in startRecording()
	 * Precondition: The microphone instance must have used startRecording() at least once.
	 *@return AudioFormat is from javax.sound.sampled
	 * @see AudioFormat, startRecording()
	 */
	public AudioFormat getAudioFormat()
	{
		return format;
	}
	
	/**
	 * Returns the Clip produced from stopRecording().
	 * Precondition: The microphone instance must have used stopRecording() at least once.
	 *@return Clip is from javax.sound.sampled
	 * @see Clip, stopRecording()
	 */
	public Clip getClip()
	{
		return audioClip;
	}
	
	/**
	 * Returns the AudioInputStream produced from stopRecording().
	 * Precondition: The microphone instance must have used stopRecording() at least once.
	 *@return AudioInputStream is from javax.sound.sampled
	 * @see AudioInputStream, stopRecording()
	 */
	public AudioInputStream getAudioInputStream()
	{
		return audioIn;
	}
	
	/**
	 * Returns the data produced from stopRecording().
	 * Precondition: The microphone instance must have used stopRecording() at least once.
	 *@return byte [] is the data as a byte array.
	 * @see byte [], stopRecording()
	 */
	public byte [] getData()
	{
		return buffer;
	}
	
	/**
	 * Checks to see if the microphone is recording or not.
	 *@return Boolean true => the mic is recording, false => the mic is not recording.
	 * @see startRecording(), stopRecording()
	 */
	public boolean isRecording()
	{
		return isRecording;
	}
}
