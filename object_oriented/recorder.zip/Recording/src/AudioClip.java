import java.io.*;
import javax.sound.sampled.*;
import javax.swing.*;

public class AudioClip extends JFrame 
{
	JPanel panel; 				
	Clip audioClip;				
	// additional attributes go here
	
	// Creates a default audioClip.
	public AudioClip()
	{
		panel = new JPanel();
		this.add(panel);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    this.setSize(300, 200);
	    this.setVisible(true);
		try {
	         audioClip = AudioSystem.getClip();
	      } catch (LineUnavailableException e) {
	         e.printStackTrace();
	      }
	}

	/*required methods:
	 * setAudioClip(...)
	 * play()
	 * stop()
	 * setName(...)
	 * getName(...)
	 * isPlaying()
	 */
	
}