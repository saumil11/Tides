/* Helpful Notes:
SoundManager Methods: 
playBass();  			  -> plays a bass sound once. (B)
playSanre(); 			  -> plays a snare sound once. (s)
waitQuareter();				-> plays no sound for 250 milliseconds
waitHalf();				-> plays no sound for 500 milliseconds
waitSecond();				-> plays no sound for 1000 milliseconds (1 second)
wait(int milliseconds)       -> plays no sound for the specified amount of milliseconds
*/
import java.util.Scanner;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SoundManager studio = new SoundManager();
		
	}
}
