//geterateNote(); 			plays a random note and returns an integer between [1,7] That corresponds to a piano note.
//1 = The note C    2 = D      3 = E		4 = F		5 = G		6 = A		7 = B

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		SoundManager studio = new SoundManager();

		int note = studio.generateNote();
		System.out.println(note);
	}
}
