import java.util.Scanner;

/* Helpful Notes:
SoundManager functions: 
playScale(Sting word); 		--> sings a C major scale using the specified word
*/

public class Main {	
	
	public static void main(String[] args) {
		TTSManager studio = new TTSManager();
				
	}	
}
