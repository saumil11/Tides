//use UI.display(String) to specify the image to show

import java.util.Scanner;

public class Main extends UI {
	protected void main() {
		String[][] countries = {{"Iran", "Iran.png"}, {"Mexico", "Mexico.png"}, {"India", "India.jpg"}, {"America", "America.jpg"}, {"China", "China.png"}, {"Korea", "Korea.png"}, {"Japan", "Japan.png"}, {"Saudi Arabia", "Saudi Arabia.png"}, {"Kuwait", "Kuwait.png"}, {"Philippines", "Philippines.png"}, {"Armenia", "Armenia.png"}, {"Russia", "Russia.png"}, {"Brazil", "Brazil.png"}, {"Argentina", "Argentina.png"}, {"El Salvador", "El Salvador.png"}, {"Guatemala", "Guatemala.png"}};

	}
}
