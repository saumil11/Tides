
public class Main {

	SoundManager studio = new SoundManager();    // Creates an instance of the SoundManager class called studio 
	UIManager UI = new UIManager(this);			// Creates an instance of the UI
	
	public static void main(String[] args) {   
		Main m = new Main();              // Creates the UI and buttons
	}
	
	public void polkaClicked(){    // Function Called when the polka button is clicked
		for(int i =0;i<5;i++){
			studio.playBass();
			studio.waitQuarter();
			studio.playSnare();
			studio.waitQuarter();
		}
	}
			
	public void myBeatClicked(){   // Function Called when the MyBeat Button is clicked
		
	}
}