/* Helpful Notes:
SoundManager Methods: 
playBass();  			  -> plays a bass sound once. (X)
playSanre(); 			  -> plays a snare sound once. (x)
waitQuareter();				-> plays no sound for 250 milliseconds (r)
waitHalf();				-> plays no sound for 500 milliseconds
waitSecond();				-> plays no sound for 1000 milliseconds (1 second)
wait(int milliseconds)       -> plays no sound for the specified amount of milliseconds
*/

public class Main {

	SoundManager studio = new SoundManager();    // Creates an instance of the SoundManager class called studio 
	UIManager UI = new UIManager(this);			// Creates an instance of the UI
	
	public static void main(String[] args) {   
		Main m = new Main();              // Creates the UI and buttons
	}
	
	public void polkaClicked(){    // Function Called when the polka button is clicked
		for(int i =0;i<5;i++){
			studio.playBass();
			studio.waitQuarter();
			studio.playSnare();
			studio.waitQuarter();
		}
	}
			
	public void myBeatClicked(){   // Function Called when the MyBeat Button is clicked
		
	}
}