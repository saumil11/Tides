/* Helpful Notes:
SoundManager Methods: 
playBass();  			  -> plays a bass sound once. (X)
playSanre(); 			  -> plays a snare sound once. (x)
waitQuareter();				-> plays no sound for 250 milliseconds (r)
waitHalf();				-> plays no sound for 500 milliseconds
waitSecond();				-> plays no sound for 1000 milliseconds (1 second)
wait(int milliseconds)       -> plays no sound for the specified amount of milliseconds
*/

public class Main {

	SoundManager studio = new SoundManager();    // Creates an instance of the SoundManager class called studio 
	UIManager UI = new UIManager(this);
	public static void main(String[] args) {   
		Main m = new Main();  
		
	}
	
	
	
	public void polkaClicked(){    // Function Called when the polka button is clicked

	}
	
	public void waltzClicked(){     // Function Called when the Waltz button is clicked

	}
	
	public void salsaClicked(){		// Function Called when the Salsa button is clicked
		
	}

	public void bluesClicked(){		// Function Called when the Blues button is clicked
		
	}
	
	public void hiphopClicked(){		// Function Called when the Hip-hop button is clicked
		
	}
	
	public void gospelClicked(){   // Function Called when the Gospel button is clicked
		
	}
		
	public void myBeatClicked(){   // Function Called when the MyBeat Button is clicked
		//answer varies
	}
}