import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		SoundManager studio = new SoundManager();
		//Used if you need a shortcut for filenames
		String fileNames[] = {"Banda1.wav","Banda2.wav","Bhangra1.wav","Bhangra2.wav","Bluegrass1.wav","Bluegrass2.wav","ChineseOpera1.wav","ChineseOpera2.wav","ChinesePop1.wav","ChinesePop2.wav","ClassicalIndian1.wav","ClassicalIndian2.wav","ClassicalKorean1.wav","ClassicalKorean2.wav","Country1.wav","Country2.wav","Gospel1.wav","Gospel2.wav","Hip-Hop1.wav","Hip-Hop2.wav","Jazz1.wav","Jazz2.wav","KoreanPop1.wav","KoreanPop2.wav","Mariachi1.wav","Mariachi2.wav","Norteno1.wav","Norteno2.wav","PersianClassical1.wav","PersianClassical2.wav","PersianPop1.wav","PersianPop2.wav","Taiko1.wav","Taiko2.wav"};
		
		//first index is genres name, second and third indexes are the file names of the two songs associated with it
		String[][] genres = {{"arabic khaleeji","ArabicKhaleeji1.wav","ArabicKhaleeji2.wav"},{"banda","Banda1.wav","Banda2.wav"},{"bhangra","Bhangra1.wav","Bhangra2.wav"},{"bluegrass","Bluegrass1.wav","Bluegrass2.wav"},{"chinese opera","ChineseOpera1.wav","ChineseOpera2.wav"},{"chinese pop","ChinesePop1.wav","ChinesePop2.wav"},{"classical indian","ClassicalIndian1.wav","ClassicalIndian2.wav"},{"classical korean","ClassicalKorean1.wav","ClassicalKorean2.wav"},{"country","Country1.wav","Country2.wav"},{"gospel","Gospel1.wav","Gospel2.wav"},{"hiphop","Hip-Hop1.wav","Hip-Hop2.wav"},{"jazz","Jazz1.wav","Jazz2.wav"},{"korean pop","KoreanPop1.wav","KoreanPop2.wav"},{"mariachi","Mariachi1.wav","Mariachi2.wav"},{"norteno","Norteno1.wav","Norteno2.wav"},{"persian classical","PersianClassical1.wav","PersianClassical2.wav"},{"persian pop","PersianPop1.wav","PersianPop2.wav"},{"taiko","Taiko1.wav","Taiko2.wav"}};

	}
}