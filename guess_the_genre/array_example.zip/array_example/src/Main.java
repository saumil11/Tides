import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {

		SoundManager studio = new SoundManager();
		
		//Storing the file names in an array called notes
		String notes[] = {"C.wav","D.wav","E.wav","F.wav","G.wav","A.wav","B.wav","C2.wav"};
		
		//Creating an array that uses the notes array to make a melody
		String melody[] = {notes[0], notes[0],notes[4],notes[4],notes[5],notes[5],notes[4]};
		for(int i =0; i<melody.length;i++){
			studio.playFile(melody[i]);
			studio.waitSecond();
		}
		
		// This Code plays a C Major chord, comment it out and try it out
		/*studio.playFile(notes[0]);
		studio.playFile(notes[2]);
		studio.playFile(notes[4]);*/
	
	}
}